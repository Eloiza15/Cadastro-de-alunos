﻿namespace Cadastro_de_alunos_Eloiza
{
    partial class CadastrodeAlunos
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblNascimento = new Label();
            lblCurso = new Label();
            lblTelefone = new Label();
            txtNome = new TextBox();
            txtNascimento = new TextBox();
            txtCurso = new TextBox();
            txtTelefone = new TextBox();
            btnCadastrar = new Button();
            btnListar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            btnLimpar = new Button();
            dgvListar = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvListar).BeginInit();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(71, 54);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(65, 25);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblNascimento
            // 
            lblNascimento.AutoSize = true;
            lblNascimento.Location = new Point(71, 103);
            lblNascimento.Name = "lblNascimento";
            lblNascimento.Size = new Size(110, 25);
            lblNascimento.TabIndex = 1;
            lblNascimento.Text = "Nascimento:";
            // 
            // lblCurso
            // 
            lblCurso.AutoSize = true;
            lblCurso.Location = new Point(71, 153);
            lblCurso.Name = "lblCurso";
            lblCurso.Size = new Size(62, 25);
            lblCurso.TabIndex = 2;
            lblCurso.Text = "Curso:";
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(71, 199);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(81, 25);
            lblTelefone.TabIndex = 3;
            lblTelefone.Text = "Telefone:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(187, 51);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(245, 31);
            txtNome.TabIndex = 1;
            // 
            // txtNascimento
            // 
            txtNascimento.Location = new Point(187, 100);
            txtNascimento.Name = "txtNascimento";
            txtNascimento.Size = new Size(245, 31);
            txtNascimento.TabIndex = 2;
            // 
            // txtCurso
            // 
            txtCurso.Location = new Point(187, 150);
            txtCurso.Name = "txtCurso";
            txtCurso.Size = new Size(245, 31);
            txtCurso.TabIndex = 3;
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(187, 196);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(245, 31);
            txtTelefone.TabIndex = 4;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(21, 261);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(112, 34);
            btnCadastrar.TabIndex = 5;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnListar
            // 
            btnListar.Location = new Point(150, 261);
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(112, 34);
            btnListar.TabIndex = 6;
            btnListar.Text = "Listar";
            btnListar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(281, 261);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(112, 34);
            btnEditar.TabIndex = 7;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(411, 261);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(112, 34);
            btnExcluir.TabIndex = 8;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(540, 261);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            // 
            // dgvListar
            // 
            dgvListar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListar.Location = new Point(21, 311);
            dgvListar.Name = "dgvListar";
            dgvListar.RowHeadersWidth = 62;
            dgvListar.Size = new Size(631, 220);
            dgvListar.TabIndex = 10;
            // 
            // CadastrodeAlunos
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(698, 543);
            Controls.Add(dgvListar);
            Controls.Add(btnLimpar);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnListar);
            Controls.Add(btnCadastrar);
            Controls.Add(txtTelefone);
            Controls.Add(txtCurso);
            Controls.Add(txtNascimento);
            Controls.Add(txtNome);
            Controls.Add(lblTelefone);
            Controls.Add(lblCurso);
            Controls.Add(lblNascimento);
            Controls.Add(lblNome);
            Name = "CadastrodeAlunos";
            Text = "Cadastro de Alunos";
            ((System.ComponentModel.ISupportInitialize)dgvListar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblNascimento;
        private Label lblCurso;
        private Label lblTelefone;
        private TextBox txtNome;
        private TextBox txtNascimento;
        private TextBox txtCurso;
        private TextBox txtTelefone;
        private Button btnCadastrar;
        private Button btnListar;
        private Button btnEditar;
        private Button btnExcluir;
        private Button btnLimpar;
        private DataGridView dgvListar;
    }
}
