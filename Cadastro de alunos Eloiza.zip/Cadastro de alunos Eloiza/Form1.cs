namespace Cadastro_de_alunos_Eloiza
{
    public partial class CadastrodeAlunos : Form
    {
        public CadastrodeAlunos()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try 
            {
                string nome = txtNome.Text;
                string nascimento = txtNascimento.Text;
                string curso = txtCurso.Text;
                string telefone = txtTelefone.Text;



            }
            
        }
    }
}
