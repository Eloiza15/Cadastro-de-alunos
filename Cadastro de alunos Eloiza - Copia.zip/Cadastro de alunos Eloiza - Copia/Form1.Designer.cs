﻿namespace Cadastro_de_alunos_Eloiza
{
    partial class CadastrodeAlunos
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblNascimento = new Label();
            lblCurso = new Label();
            lblTelefone = new Label();
            txtNome = new TextBox();
            txtCurso = new TextBox();
            txtTelefone = new TextBox();
            btnCadastrar = new Button();
            btnListar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            btnLimpar = new Button();
            dataGridAlunos = new DataGridView();
            txtNascimento = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridAlunos).BeginInit();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(50, 32);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(43, 15);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblNascimento
            // 
            lblNascimento.AutoSize = true;
            lblNascimento.Location = new Point(50, 62);
            lblNascimento.Margin = new Padding(2, 0, 2, 0);
            lblNascimento.Name = "lblNascimento";
            lblNascimento.Size = new Size(74, 15);
            lblNascimento.TabIndex = 1;
            lblNascimento.Text = "Nascimento:";
            // 
            // lblCurso
            // 
            lblCurso.AutoSize = true;
            lblCurso.Location = new Point(50, 92);
            lblCurso.Margin = new Padding(2, 0, 2, 0);
            lblCurso.Name = "lblCurso";
            lblCurso.Size = new Size(41, 15);
            lblCurso.TabIndex = 2;
            lblCurso.Text = "Curso:";
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Location = new Point(50, 119);
            lblTelefone.Margin = new Padding(2, 0, 2, 0);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(55, 15);
            lblTelefone.TabIndex = 3;
            lblTelefone.Text = "Telefone:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(131, 31);
            txtNome.Margin = new Padding(2);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(173, 23);
            txtNome.TabIndex = 1;
            // 
            // txtCurso
            // 
            txtCurso.Location = new Point(131, 90);
            txtCurso.Margin = new Padding(2);
            txtCurso.Name = "txtCurso";
            txtCurso.Size = new Size(173, 23);
            txtCurso.TabIndex = 3;
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(131, 118);
            txtTelefone.Margin = new Padding(2);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(173, 23);
            txtTelefone.TabIndex = 4;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(15, 157);
            btnCadastrar.Margin = new Padding(2);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(78, 26);
            btnCadastrar.TabIndex = 5;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnListar
            // 
            btnListar.Location = new Point(105, 157);
            btnListar.Margin = new Padding(2);
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(78, 26);
            btnListar.TabIndex = 6;
            btnListar.Text = "Listar";
            btnListar.UseVisualStyleBackColor = true;
            btnListar.Click += btnListar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(197, 157);
            btnEditar.Margin = new Padding(2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(78, 26);
            btnEditar.TabIndex = 7;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(288, 157);
            btnExcluir.Margin = new Padding(2);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(78, 26);
            btnExcluir.TabIndex = 8;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(378, 157);
            btnLimpar.Margin = new Padding(2);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(78, 26);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            // 
            // dataGridAlunos
            // 
            dataGridAlunos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridAlunos.Location = new Point(15, 187);
            dataGridAlunos.Margin = new Padding(2);
            dataGridAlunos.Name = "dataGridAlunos";
            dataGridAlunos.RowHeadersWidth = 62;
            dataGridAlunos.Size = new Size(442, 132);
            dataGridAlunos.TabIndex = 10;
            dataGridAlunos.CellDoubleClick += dataGridAlunos_CellDoubleClick;
            // 
            // txtNascimento
            // 
            txtNascimento.Location = new Point(131, 62);
            txtNascimento.Mask = "00/00/0000";
            txtNascimento.Name = "txtNascimento";
            txtNascimento.Size = new Size(173, 23);
            txtNascimento.TabIndex = 2;
            // 
            // CadastrodeAlunos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(489, 326);
            Controls.Add(txtNascimento);
            Controls.Add(dataGridAlunos);
            Controls.Add(btnLimpar);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnListar);
            Controls.Add(btnCadastrar);
            Controls.Add(txtTelefone);
            Controls.Add(txtCurso);
            Controls.Add(txtNome);
            Controls.Add(lblTelefone);
            Controls.Add(lblCurso);
            Controls.Add(lblNascimento);
            Controls.Add(lblNome);
            Margin = new Padding(2);
            Name = "CadastrodeAlunos";
            Text = "Cadastro de Alunos";
            ((System.ComponentModel.ISupportInitialize)dataGridAlunos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblNascimento;
        private Label lblCurso;
        private Label lblTelefone;
        private TextBox txtNome;
        private TextBox txtCurso;
        private TextBox txtTelefone;
        private Button btnCadastrar;
        private Button btnListar;
        private Button btnEditar;
        private Button btnExcluir;
        private Button btnLimpar;
        private DataGridView dgvListar;
        private MaskedTextBox txtNascimento;
        private DataGridView dataGridAlunos;
    }
}
