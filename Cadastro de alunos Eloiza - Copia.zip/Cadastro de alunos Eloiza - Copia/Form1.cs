using MySql.Data.MySqlClient;
using System.Data;
using System.Security.Cryptography.X509Certificates;

namespace Cadastro_de_alunos_Eloiza
{
    public partial class CadastrodeAlunos : Form
    {
        public CadastrodeAlunos()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = txtNome.Text;
                string data_nascimento = txtNascimento.Text;
                string curso = txtCurso.Text;
                string telefone = txtTelefone.Text;

                if (nome != "" && data_nascimento != "" && curso != "" && telefone != "")
                {
                    string conexaoBanco = "" + "Server=localhost; Database=Escola; Uid=root; Pwd=''";

                    MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                    conexao.Open();

                    DateTime dataMysqlFormat = Convert.ToDateTime(data_nascimento);
                    string dataNascimentoFormatada = dataMysqlFormat.ToString("yyyy-MM-dd");

                    string consultaUsuario = "SELECT COUNT(*) FROM Alunos Where nome = @nome";
                    MySqlCommand comandoConsulta = new MySqlCommand(consultaUsuario, conexao);
                    comandoConsulta.Parameters.AddWithValue("@nome", nome);

                    int usuarioExistente = Convert.ToInt32(comandoConsulta.ExecuteScalar());
                    if (usuarioExistente > 0)
                    {
                        MessageBox.Show("Este aluno j� foi cadastrado");
                    }
                    else
                    {

                        string inserirUsuario = "INSERT INTO Alunos (nome, data_nascimento, curso, telefone) VALUES (@nome, @data_nascimento, @curso, @telefone)";
                        MySqlCommand comandoInserir = new MySqlCommand(inserirUsuario, conexao);
                        comandoInserir.Parameters.AddWithValue("@nome", nome);
                        comandoInserir.Parameters.AddWithValue("@data_nascimento", dataNascimentoFormatada);
                        comandoInserir.Parameters.AddWithValue("@curso", curso);
                        comandoInserir.Parameters.AddWithValue("@telefone", telefone);

                        int registros = comandoInserir.ExecuteNonQuery();
                        if (registros > 0)
                        {
                            MessageBox.Show("Aluno cadastrado com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("N�o foi poss�vel cadastrar o aluno. Tente novamente.");
                        }

                    }

                    conexao.Close();

                }
                else
                {
                    MessageBox.Show("Preencha os campos corretamente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro inesperado: " + ex.Message);
            }

        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            try
            {
                string conexaoBanco = "" + "Server=localhost; Database=Escola; Uid=root; Pwd=''";

                MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                conexao.Open();

                string consultaAlunos = "SELECT * FROM Alunos";
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter(consultaAlunos, conexao);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridAlunos.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar alunos " + ex.Message);
            }
        }

        private int id_aluno;

        private void dataGridAlunos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow linhaSelecionada = dataGridAlunos.Rows[e.RowIndex];

                    id_aluno = Convert.ToInt32(linhaSelecionada.Cells["id"].Value);
                    txtNome.Text = linhaSelecionada.Cells["nome"].Value.ToString();
                    txtNascimento.Text = Convert.ToDateTime(linhaSelecionada.Cells["data_nascimento"].Value).ToString("dd-MM-yyyy");
                    txtCurso.Text = linhaSelecionada.Cells["curso"].Value.ToString();
                    txtTelefone.Text = linhaSelecionada.Cells["telefone"].Value.ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar dados do aluno: " + ex.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {

                if (id_aluno > 0)
                {
                    string conexaoBanco = "Server=localhost; Database=Escola; Uid=root; Pwd=''";
                    MySqlConnection conexao = new MySqlConnection(conexaoBanco);
                    conexao.Open();



                    DateTime dataMysqlFormat = Convert.ToDateTime(txtNascimento.Text);
                    string dataNascimentoFormatada = dataMysqlFormat.ToString("yyyy-MM-dd");

                    string atualizarAluno = "UPDATE Alunos SET data_nascimento = @data_nascimento, curso = @curso, telefone = @telefone WHERE id = @id";
                    MySqlCommand comandoAtualizar = new MySqlCommand(atualizarAluno, conexao);

                    comandoAtualizar.Parameters.AddWithValue("@id", id_aluno);
                    comandoAtualizar.Parameters.AddWithValue("@nome", txtNome.Text);
                    comandoAtualizar.Parameters.AddWithValue("@data_nascimento", dataNascimentoFormatada);
                    comandoAtualizar.Parameters.AddWithValue("@curso", txtCurso.Text);
                    comandoAtualizar.Parameters.AddWithValue("@telefone",txtTelefone.Text);

                    int registros = comandoAtualizar.ExecuteNonQuery();
                    if (registros > 0)
                    {
                        MessageBox.Show("Dados do aluno atualizados com sucesso!");
                    }
                    else

                    {
                        MessageBox.Show("N�o foi poss�vel atualizar os dados do aluno. Tente novamente.");
                    }

                    conexao.Close();
                }
                else
                {
                    MessageBox.Show("Preencha os campos corretamente");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar aluno: " + ex.Message);
            }
        }
    }
}
    